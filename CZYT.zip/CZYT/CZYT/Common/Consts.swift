//
//  Consts.swift
//  CZYT
//
//  Created by jerry cheng on 2016/11/6.
//  Copyright © 2016年 chester. All rights reserved.
//


import UIKit

class Consts: NSObject {
    
    static var umengAppKey = "5833ef1c677baa0bdf00053d" //友盟统计appkey
    static var RCIMAppKey = "k51hidwqk00xb"//"m7ua80gbmyydm"
    static var DeviceToken:String = ""
}
