//
//  GroupLineCell.swift
//  CZYT
//
//  Created by jerry cheng on 2016/11/17.
//  Copyright © 2016年 chester. All rights reserved.
//

import UIKit

class GroupLineCell: UICollectionViewCell {

    @IBOutlet weak var nameLabel:UILabel!
    @IBOutlet weak var detailLabel:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
