//
//  Reflect+Convert.swift
//  Reflect
//
//  Created by 成林 on 15/8/23.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import Foundation

extension Reflect{
    
    func toDict() -> [String: AnyObject]{
        
        var dict: [String: AnyObject] = [:]
        
        self.properties { (name, type, value) -> Void in
            if "\(value)" == "nil" {
                return
            }
            if type.isOptional{
                
                if type.isReflect {
                    
                    dict[name] = (value as? Reflect)?.toDict()
                    
                }else{
                    var str = String(value)
                    if str.contain(subStr: "Optional(")
                    {
                        str = str.substringFromIndex(str.startIndex.advancedBy(10))
                        if str.characters.count > 1
                        {
                            str = str.substringToIndex(str.endIndex.advancedBy(-2))
                        }else{
                            str = str.substringToIndex(str.endIndex.advancedBy(-1))
                        }
                    }
                    dict[name] = str
                }
                
            }else{
                
                if type.isReflect {
                    
                    if type.isArray {
                        
                        var dictM: [[String: AnyObject]] = []
                        
                        let modelArr = value as! NSArray
                        
                        for item in  modelArr {
                            
                            let dict = (item as! Reflect).toDict()
                            
                            dictM.append(dict)
                        }
                        
                        dict[name] = dictM
                        
                    }else{
                        
                        dict[name] = (value as! Reflect).toDict()
                    }
                    
                }else{
                    var str = String(value)
                    if str.contain(subStr: "Optional(")
                    {
                        str = str.substringFromIndex(str.startIndex.advancedBy(10))
                        if str.characters.count > 1
                        {
                            str = str.substringToIndex(str.endIndex.advancedBy(-2))
                        }else{
                            str = str.substringToIndex(str.endIndex.advancedBy(-1))
                        }
                    }
                    dict[name] = str
//                    dict[name] = "\(value)".replacingOccurrencesOfString("Optional(", withString: "").replacingOccurrencesOfString(")", withString: "").replacingOccurrencesOfString("\"", withString: "")
                }
            }
            
        }
        
        return dict
    }
}

