//
//  DNBadgeLabel.h
//  ImagePicker
//
//  Created by DingXiao on 15/2/27.
//  Copyright (c) 2015年 Dennis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DNBadgeLabel : UIView

@property (nonatomic, copy) NSString *title;

@end
