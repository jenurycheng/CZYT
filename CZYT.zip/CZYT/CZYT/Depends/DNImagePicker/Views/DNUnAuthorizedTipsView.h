//
//  UnAuthorizedTipsView.h
//  ImagePicker
//
//  Created by DingXiao on 15/3/18.
//  Copyright (c) 2015年 Dennis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DNUnAuthorizedTipsView : UIView
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *label;
@end
